<!DOCTYPE HTML>  
<html>
  <head >
  <title>login</title>
  <link rel="stylesheet" href="css/login.css">
  <?php require_once 'js/js-login.php'; ?>
    </head >
    <body> 
      <fieldset>
        <img src="files/gpl.png" alt="gpl" width="150px">
		       <h3 align= "right">

		      <a href="../">  Home ||  </a> 
		       <a href="login.php">  Login ||  </a>  
		       <a href="registration.php">  Registration </a>
		   </h3>  	
       </fieldset>
    <?php       
  session_start();

 if(!isset($_SESSION['nameErr']))
 {
   $_SESSION['nameErr']="";
 }

 if(!isset($_SESSION['passwordErr']))
 {
   $_SESSION['passwordErr']="";
 }

 $name=$password="";
 
    ?>        
		  <fieldset>
		  <h1>Agent Login</h1>
          <form action="controller/login.php" method="POST" onsubmit="validateform()" enctype="multipart/form-data"> 
		  
		  
		       <b> <label for="username"> Username : </label> </b>
			   <input type="text" name="name" id="name"  onkeyup="myFunction1()"  onmousedown="myFunction1()" onkeypress="checkName()" onblur="checkName()" >	
               <span id="nameErr"> <?php echo $_SESSION['nameErr'];?></span><br>			   
               <br><br>
			  
			    <b> <label for="password"> Password : </label> </b>
                <input type="password" name="password" id="password" onkeyup="myFunction2()" onmousedown="myFunction2()" onkeypress="checkPassword()" onblur="checkPassword()" >  
				<span  id="passwordErr"> <?php echo $_SESSION['passwordErr'];?></span><br>
                <br><br>
				
                <hr>
                <input type="checkbox" name="Remember me"> Remember Me <br><br>
                <input type="submit" name="submit" value="Submit"> 				
               			
							
         </form> <br><br>
				
            </fieldset>            		
         </form> 
	 
    </body>
</html>
<?php
if(isset($_SESSION['passwordErr']) || isset($_SESSION['passwordErr']))
 {
 session_destroy();
 }

  ?>