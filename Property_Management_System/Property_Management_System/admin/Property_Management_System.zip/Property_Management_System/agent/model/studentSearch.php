<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
		table,td,th{
      width: 600px;
			border:1px solid black;
      border-width: 3px;
      border-color: #8D91BD;
		}
		th,td {
  	padding:9px;
	}
	</style>
</head>
<body>
		<?php

$connect = mysqli_connect("localhost", "root", "", "pms");
$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($connect, $_POST["query"]);
 $query = "
  SELECT * FROM buyer 
  WHERE b_firstname LIKE '%".$search."%'
  OR b_username LIKE '%".$search."%' 
 ";
}
else
{
 $query = "SELECT * FROM buyer ORDER BY b_id";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
 $output .=  '  
 <table >
    <tr>
     <th>Name</th>
     <th>UserName</th>
     <th>E-mail</th>
    </tr>
 '  ;
 while($row = mysqli_fetch_array($result))
 {
  $output .=' 
   <tr>
    <td>  '.$row["b_firstname"]." ".$row["b_lastname"].' </td>
    <td>  '.$row["b_username"].' </td>
    <td>  '.$row["b_email"].' </td>
   </tr>
  '  ;
 }
 echo $output;
}
else
{
 echo 'Not found';
}

?>