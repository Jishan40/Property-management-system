<?php 

require_once 'db_connect.php';


function login($Data)
{
	$conn = db_conn();
	$selectQuery = "SELECT * FROM `agent` where a_username = :username AND  a_password= :password ";
    try {
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute(
		array(
		':username'=> $_POST["a_username"],
		':password'=> $_POST["a_password"],
		)		
		);
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
    

   $conn = null;
    return true;
}

function add($data){
	$conn = db_conn();
    $selectQuery = "INSERT into agent (a_firstname, a_username, a_password, a_phone, a_email)
VALUES (:username, :password, :name, :contactno, :email)";
    try{
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([
            ':name' => $data['a_firstname'],
        	':username' => $data['a_username'],
        	':password' => $data['a_password'],
        	':contactno' => $data['a_phone'],
        	':email' => $data['a_email']
        ]);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    
    $conn = null;
    return true;
}


function showData($columnName)
{
	$conn = db_conn();
	$selectQuery = "SELECT * FROM `agent` where a_username = ?";
    try {
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([$columnName]);
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row;
}

function pass($username, $data){
    $conn = db_conn();
    $selectQuery = "UPDATE `agent` set  a_password = ?,  where a_username = ?";
    try{
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([
        	 $data['a_password'], $username
        ]);
    }catch(PDOException $e){
        echo $e->getMessage();
    }    
    $conn = null;
    return true;
}

function profile($username, $data){
    $conn = db_conn();
    $selectQuery = "UPDATE `agent` set   a_email = ?, a_phone=?,  a_firstname=?  where a_username = ?";
    try{
        $stmt = $conn->prepare($selectQuery);
        $stmt->execute([
        	  $data['a_email'],$data['a_phone'],$data['a_firstname'],$username
        ]);
    }catch(PDOException $e){
        echo $e->getMessage();
    }    
    $conn = null;
    return true;
}






function searchUsername($username){
    $conn = db_conn();
    $selectQuery = "SELECT * FROM `agent` WHERE a_username = '$username'";

    try{
        $stmt = $conn->query($selectQuery);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $rows;
}



function updatePassword($username, $password){
    $conn = db_conn();
    $selectQuery = "UPDATE agent set a_password = '$password' where a_username = '$username'";
    try{
          $stmt = $conn->query($selectQuery);
      
    }catch(PDOException $e){
        echo $e->getMessage();
    }

    $conn = null;
    return true;
}


 
 ?>






