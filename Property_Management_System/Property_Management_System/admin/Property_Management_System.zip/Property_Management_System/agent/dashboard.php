
<?php
session_start();
if(isset($_SESSION['username']))
{
?>
<!DOCTYPE html>
<html> 
	<head>
	<link rel="stylesheet" href="css/dashboard.css">
	</head>  
	<body>
		<fieldset class="fieldhead">
			<h1 > Agent  </h1>
			<img src="files/gpl.png" alt="gpl" width="150px">
			<h3 align= "right">
			<hr>
			
			Logged in as <?php echo $_SESSION['nameDB']; ?>|
			<a href="logout.php">Logout</a>   
			</h3>  
		</fieldset>

		<fieldset class="fieldbody">
		
		     <h1  align="center"> Welcome <?php echo $_SESSION['nameDB']; ?>  <h1/>
            <h4>
            <h2> <u> Account </u> </h2> 
            <ul>
			   <li> <a href="dashboard.php"> Dashboard   </a></li><hr>
                <li> <a href= "viewProfile.php"> View Profile </a> </li><hr>
                <li> <a href="editProfile.php"> Edit Profile </a></li><hr>
                <li> <a href="changePassword.php">Change Password</a> </li><hr>  
                <li> <a href="studentSearch.php">Buyers</a> </li></ul>
      
		     </ul>  
		     </h4>
		     

		   </fieldset>
		 
	 </body>
	 
</html>	
<?php
}
else
{ header("location:login.php");}
?> 