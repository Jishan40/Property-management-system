<?php 
require_once ('model/model.php');
function fetchProfile($username){
	return showData($username);
}
?>
