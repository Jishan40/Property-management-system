function validateForm() {
	refresh();
	var hasError = false;
    var fname = document.getElementById("fname");
    var lname = document.getElementById("lname");
    var uname = document.getElementById("uname");
    var dob = document.getElementById("dob");
    var phone = document.getElementById("phone");
    var email = document.getElementById("email");
    var pass = document.getElementById("pass");
    var male = document.getElementById("male");
    var female = document.getElementById("female");
    var other = document.getElementById("other");
    var file = document.getElementById("aImage");
    var emPatt = /^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/;
    var num = /^[\d]*$/;
    var name = /^[a-zA-Z\s]+$/;
    var emRes = emPatt.test(email.value);
    var numRes = num.test(phone.value);
    var fnameRes = name.test(fname.value);
    var lnameRes = name.test(lname.value);
    var passcheck = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{6,}$/;
    var validPass = passcheck.test(pass.value);

    if (fname.value == "") {
      document.getElementById("err-fname").innerHTML=" * Please fill out first name";
      fname.style.border="2px solid red";
      hasError = true;
    }else if(!fnameRes){
      document.getElementById("err-fname").innerHTML=" * Please fill out a valid name";
      fname.style.border="2px solid red";
    }
    if(lname.value == ""){
      hasError = false;
    }else if (!lnameRes) {
      document.getElementById("err-lname").innerHTML=" Please fill out a valid name";
      lname.style.border="2px solid red";
      hasError = true;
    }
    if (uname.value == "") {
      document.getElementById("err-uname").innerHTML=" * Please fill out username";
      uname.style.border="2px solid red";
      hasError = true;
    }
    if (dob.value == "") {
      document.getElementById("err-dob").innerHTML=" * Please fill the date of birth";
      dob.style.border="2px solid red";
      hasError = true;
    }
    if(phone.value == ""){
      document.getElementById("err-phone").innerHTML=" * Please provide a phone number";
      phone.style.border="2px solid red";
      hasError = true;
    }else if(!numRes){
      document.getElementById("err-phone").innerHTML=" * Phone number is not correct";
      phone.style.border="2px solid red";
      hasError = true;
    }
    if(email.value == ""){
      document.getElementById("err-email").innerHTML=" * Please provide a valid email";
      email.style.border="2px solid red";
      hasError = true;
    }else if(!emRes){
      document.getElementById("err-email").innerHTML=" * Email format is not correct";
      email.style.border="2px solid red";
      hasError = true;
    }
    if (pass.value == "") {
      document.getElementById("err-pass").innerHTML=" * Please fill out password";
      pass.style.border="2px solid red";
      hasError = true;
    }else if((pass.value).length < 6){
      document.getElementById("err-pass").innerHTML=" * Password will 6 character long";
      pass.style.border="2px solid red";
		  hasError = true;
    }else if(!validPass){
      document.getElementById("err-pass").innerHTML=" * Password must be 6 characters<br>Must be use [(0-9), (A-Z), (a-z)]";
      pass.style.border="2px solid red";
		  hasError = true;
    }
    if (!male.checked && !female.checked && !other.checked) {
        document.getElementById("err-gender").innerHTML=" * Choose anyone";
        hasError = true;
    }
    if (file.value == "") {
        document.getElementById("err-aImage").innerHTML=" * Please upload a file";
        hasError = true;
    }
	return !hasError;
}
function refresh(){
	
	document.getElementById("err-fname").innerHTML=" *";
  document.getElementById("err-lname").innerHTML="";
  document.getElementById("err-uname").innerHTML=" *";
  document.getElementById("err-dob").innerHTML=" *";
  document.getElementById("err-phone").innerHTML=" *";
	document.getElementById("err-email").innerHTML=" *";
	document.getElementById("err-pass").innerHTML=" *";
	document.getElementById("err-gender").innerHTML=" *";
	document.getElementById("err-aImage").innerHTML=" *";
  fname.style.border="2px solid green";
  lname.style.border="2px solid green";
  uname.style.border="2px solid green";
  dob.style.border="2px solid green";
  phone.style.border="2px solid green";
  email.style.border="2px solid green";
  pass.style.border="2px solid green";
}