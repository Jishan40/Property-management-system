<?php
$sqlInfo="";
class db{
    
    function OpenCon()
    {
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $db = "pms";
    $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
    
    return $conn;
    }
    function CheckUser($conn,$table,$username,$password)
    {
        $result = $conn->query("SELECT * FROM ". $table." WHERE username='". $username."' AND password='". $password."'");
        return $result;
    }
    function AddAgent($conn, $table, $aFirstname, $aLastname, $aUsername, $aDob, $aGender, $aPhone, $aEmail, $aPassword, $aPhoto)
    {
        $result = $conn->query("INSERT INTO $table VALUES('','$aFirstname','$aLastname','$aUsername','$aDob','$aGender', '$aPhone', '$aEmail', '$aPassword', '$aPhoto')");
        return $result;
    }
    function searchAgent($conn,$table,$a_id)
    {
        $result = $conn->query("SELECT * FROM ". $table." WHERE a_id='". $a_id."'");
        return $result;
    }
    function searchSeller($conn,$table,$s_id)
    {
        $result = $conn->query("SELECT * FROM ". $table." WHERE s_id='". $s_id."'");
        return $result;
    }
    function adminLogin($conn,$table,$ad_id)
    {
        $result = $conn->query("SELECT * FROM ". $table." WHERE ad_id='". $ad_id."'");
        return $result;
    }
    function adminPassChange($conn,$table,$ausername,$asecurityq, $pass)
    {
        $sql = $conn->query("UPDATE $table SET ad_password='$pass' WHERE ad_username='".$ausername."' AND ad_securityQ='".$asecurityq."'");
        if ($conn->query($sql) == TRUE) {
            echo "Password Changed Successful";
            $result= TRUE;
        }else {
            echo $sqlInfo;
            $result= FALSE ;
        }
        return  $result;
    }

    function ShowAll($conn,$table)
    {
        $result = $conn->query("SELECT * FROM  $table");
        return $result;
    }

    function agentDeleteId($conn,$table, $a_id){
        $result = $conn->query("DELETE FROM `agent` WHERE a_id= $a_id");
        return $result;
    }
    function searchBoxBuyer($conn,$table){
        $result = $conn->query("SELECT b_firstname, b_lastname FROM `buyer`");
        return $result;
    }
    function sellerDeleteId($conn,$table, $s_id){
        $result = $conn->query("DELETE FROM `seller` WHERE s_id= $s_id");
        return $result;
    }
    function buyerDeleteId($conn,$table, $b_id){
        $result = $conn->query("DELETE FROM `buyer` WHERE b_id= $b_id");
        return $result;
    }

    function UpdateUser($conn,$table,$username,$fname,$lname,$dob,$gender,$phone,$email)
    {
        $sql = "UPDATE $table SET a_firstname='$fname', a_lastname='$lname', a_dob = '$dob', a_gender='$gender', a_phone='$phone',a_email='$email' WHERE a_username='$username'";

        if ($conn->query($sql) === TRUE) {
            $result= TRUE;
        } else {
            $result= FALSE ;
        }
        return  $result;
    }

    function CloseCon($conn)
    {
        $conn -> close();
    }
    
}

?>