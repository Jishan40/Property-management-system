<?php 
    session_start();
    include "../model/db.php";
    if(empty($_SESSION["username"])) 
    {
        header("Location: ../control/alogout.php"); // Redirecting To Home Page
    }
    // $data = file_get_contents("../data/agentData.json");
    // $mydata = json_decode($data);
    $connection = new db();
    $conobj=$connection->OpenCon();
    $userQuery=$connection->ShowAll($conobj,"agent");
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Agent Details</title>
    <link rel="stylesheet" href="../css/sidebar.css">
    <link rel="stylesheet" type="text/css" href="../css/agentDetails.css">
  </head>
  <body>
    <nav class="sidebar">
      
      <div class="text"><img src="../files/gpl.png" alt="">
      <span>Admin Panel</span> </div>
      <ul>
        <li><a href="adashboard.php">Dashboard</a></li>
        <li class="reg">
          <a href="">Registration
          <span>&rsaquo;</span>
          </a>
          <ul class="reg-user">
            <li><a href="registrationAgent.php">Agent</a></li>
            <li><a href="registrationSeller.php">Seller</a></li>
          </ul>
        </li>
        <li class="det active">
          <a class="activel" href="">User Details
            <span>&rsaquo;</span>
          </a>
          <ul class="user-detail">
            <li><a class="activel" href="agentDetails.php">Agent Details</a></li>
            <li><a href="buyerDetails.php">Buyer Details</a></li>
            <li><a href="sellerDetails.php">Seller Details</a></li>
          </ul>
        </li>
        <li><a href="#">Update Info</a></li>
        <li><a href="#">Remove User</a></li>
        <li><a href="publishNotice.php">Notice</a></li>
        <li><a href="#">Feedback</a></li>
      </ul>
    </nav>
    <div class="content">
        <div class="header">
            <a href="../control/alogout.php">Logout</a>
            <span>Rahul Hassan</span>
            <img src="../files/rh_0023.jpg" alt="">
        </div>
    
        <div class="body-content">
            <h2 class="topic">Agent Details</h2>
            <?php
                if ($userQuery->num_rows > 0) {
                    while($row = $userQuery->fetch_assoc()){ ?>
                        <div class="adetail">
                            <img src="<?php echo $row['a_photo']; ?>" alt="Photo">
                            <p><?php echo $row['a_firstname']; ?><?php echo " ".$row['a_lastname']; ?></p>
                            Date Of Birth: <?php echo $row['a_dob']; ?><br>
                            Gender: <?php echo $row['a_gender']; ?><br>
                            Contact No: <?php echo $row['a_phone']; ?><br>
                            Email: <?php echo $row['a_email']; ?><br>
                            <a class="editbtn" href="agentEdit.php?id=<?php echo $row['a_id'];?>"><button>Edit</button></a>
                            <a class="dltbtn" href="../control/agentDelet.php?id=<?php echo $row['a_id'];?>" onclick="return confirm('Do you want to delete <?php echo $row['a_firstname']?>?')"><button>Delete</button></a>
                        </div>
            <?php   
                    }
                }    
            ?>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <div><?php include "footer.php"; ?></div>
    </div>
  </body>
</html>
