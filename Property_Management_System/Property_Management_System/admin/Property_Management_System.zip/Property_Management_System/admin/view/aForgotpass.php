<?php
    include('../control/alogincheck.php');
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Admin Login</title>
    <link rel="stylesheet" href="../css/adminLogin.css">
	<script>
      function myFunction() {
        var x = document.getElementById("pass");
		var y = document.getElementById("pass1");
        if (x.type == "password") {
          x.type = "text";
        } else {
          x.type = "password";
        }
		if (y.type == "password") {
          y.type = "text";
        } else {
          y.type = "password";
        }
      }
    </script>
  </head>
  <body>
    <div class="center">
      <a href="home.php"><img width="165px" src="../files/gpl.png" alt=""></a>
      <form method="post">
        <p><?php echo $sinfo; ?></p>
        <div class="txt_field">
        
          <input name="securityQ" type="text" required>
          <span></span>
          <label>What is the name of your favorite pet?</label>
        </div>
        <div class="txt_field">
        
          <input name="username" type="text" required>
          <span></span>
          <label>Username</label>
        </div>
        <div class="txt_field">
        
          <input name="npass" id="pass" type="password" required>
          <span></span>
          <label>New Password</label>
        </div>
        <div class="txt_field">
          <input name="cnpass" id="pass1" type="password" required>
          <span></span>
          <label>Confirm Password</label>
        </div>
		<div><input class="showpass" type="checkbox" onclick="myFunction()"> Show Password</div>
        <div class="pass"><a href="alogin.php">Log in?</a></div>
        <input class="submitbtn" name="confirm" type="submit" value="Confirm">
      </form>
    </div>
  </body>
</html>
