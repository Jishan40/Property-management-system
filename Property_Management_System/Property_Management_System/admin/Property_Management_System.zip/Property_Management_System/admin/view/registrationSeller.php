<?php 
	include "../control/agentformcheck.php"; 
	session_start(); 
    if(empty($_SESSION["username"])) 
    {
        header("Location: ../control/alogout.php"); // Redirecting To Home Page
    }
?>

<!DOCTYPE html>
<html>
  <head>
  	<title>Registration Seller</title>
	<script src="../js/regAgentBuyer.js"></script>
	<link href="https://fonts.googleapis.com/css2?family=Teko:wght@400&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="../css/addUpdateAgent.css">
    <link rel="stylesheet" href="../css/sidebar.css">
  </head>
  <body>
    <nav class="sidebar">
		<div class="text"><img src="../files/gpl.png" alt="">
		<span>Admin Panel</span> </div>
		<ul>
        <li><a href="adashboard.php">Dashboard</a></li>
        <li class="reg active">
          <a class="activel" href="">Registration
          <span>&rsaquo;</span>
          </a>
          <ul class="reg-user">
            <li><a href="registrationAgent.php">Agent</a></li>
            <li><a class="activel" href="registrationSeller.php">Seller</a></li>
          </ul>
        </li>
        <li class="det">
          <a href="">User Details
            <span>&rsaquo;</span>
          </a>
          <ul class="user-detail">
            <li><a href="agentDetails.php">Agent Details</a></li>
            <li><a href="buyerDetails.php">Buyer Details</a></li>
            <li><a href="sellerDetails.php">Seller Details</a></li>
          </ul>
        </li>
        <li><a href="#">Update Info</a></li>
        <li><a href="#">Remove User</a></li>
        <li><a href="publishNotice.php">Notice</a></li>
        <li><a href="#">Feedback</a></li>
      </ul>
    </nav>
    <div class="content">
		<div class="header">
			<a href="../control/alogout.php">Logout</a>
			<span>Rahul Hassan</span>
			<img src="../files/rh_0023.jpg" alt="">
		</div>
		<div class="main">	
			<h2 class="headTop">Registration Seller</h2>
			<p><?php echo $msg;?></p>
			You must have to fill (<span class="err-info">*</span>) fields.<br><br>
			<form action="" name="forms" method="post" onsubmit="return validateForm()" enctype="multipart/form-data">
				<div>
					<label>First Name</label>
					<span class="err-info" id="err-fname">*<?php echo $err_fname;?></span>
					<input class="ibox align" type="text" id="fname" name="fname" placeholder="First Name">
					<br><br>
					
					<label>Last Name</label>
					<span class="err-info" id="err-lname" ><?php echo $err_lname;?></span>
					<input class="ibox align" type="text" id="lname" name="lname" placeholder="Last Name">
					
					<br><br>

					<label>Username</label>
					<span class="err-info" id="err-uname">*<?php echo $err_username;?></span>
					<input class="ibox align" type="text" id="uname" name="uname" placeholder="Username">
					
					<br><br>

					<label>Date Of Birth</label>
					<span class="err-info" id="err-dob">*<?php echo $err_dob;?></span>
					<input class="ibox align" type="date" id="dob"  placeholder="dd/mm/yyyy" max="2000-12-31" name="dob">
					<br><br>
					
					<label>Gender</label>
					<span class="err-info" id="err-gender">*<?php echo $err_gender;?></span>
					<label class="ibox align">
					<input type="radio" value="Male" id="male" name="gender"> Male
					<input type="radio" value="Female" id="female" name="gender"> Female
					<input type="radio" value="Other" id="other" name="gender"> Other
					</label>
					<br><br>
					
					<label>Phone</label>
					<span class="err-info" id="err-phone">*<?php echo $err_phone;?></span>
					<input class="ibox align" id="phone" type="phone" value="" name="phone">
					<br><br>
					
					<label>Email</label>
					<span class="err-info" id="err-email">*<?php echo $err_email;?></span>
					<input class="ibox align" type="email" id="email" value="" name="email">
					<br><br>
					
					<label>Password</label>
					<span class="err-info" id="err-pass">*<?php echo $err_pass;?></span>
					<input class="ibox align" id="pass" type="password" value="" name="pass">
					
					<br><br>

					<label>Photo</label>
					<span class="err-info" id="err-aImage">*<?php echo $err_file;?></span>
					<input class="ibox align" type="file" id="aImage" name="aImage">
					<br><br>
				</div>
				<div class="all-btn">
					<input class="btn" type="reset" name="reset" value="Reset">
					<input class="btn" type="submit" name="sellerSignup" value="Submit">
				</div>
			</form>
		</div>
      <div><?php include "footer.php"; ?></div>
    </div>
	
  </body>
</html>
