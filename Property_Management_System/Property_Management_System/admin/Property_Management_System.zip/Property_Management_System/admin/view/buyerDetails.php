<?php 
    session_start();
    include "../model/db.php";
    if(empty($_SESSION["username"])) 
    {
        header("Location: ../control/alogout.php"); // Redirecting To Home Page
    }
    $connection = new db();
    $conobj=$connection->OpenCon();
    $userQuery=$connection->ShowAll($conobj,"buyer");
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Buyer Details</title>
    <link rel="stylesheet" href="../css/sidebar.css">
    <link rel="stylesheet" type="text/css" href="../css/agentDetails.css">
    <link rel="stylesheet" type="text/css" href="../css/buyerDet.css">
    <script>
      function showHint(str) {
        if (str.length == 0) {
          document.getElementById("txtHint").innerHTML = "";
          return;
        } else {
          var xmlhttp = new XMLHttpRequest();
          xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
              document.getElementById("txtHint").innerHTML = this.responseText;
            }
          };
          xmlhttp.open("GET", "../control/buyerSearch.php?q=" + str, true);
          xmlhttp.send();
        }
      }
    </script>
  </head>
  <body>
    <nav class="sidebar">
        <div class="text"><img src="../files/gpl.png" alt="">
        <span>Admin Panel</span> </div>
        <ul>
        <li><a href="adashboard.php">Dashboard</a></li>
        <li class="reg">
          <a href="">Registration
          <span>&rsaquo;</span>
          </a>
          <ul class="reg-user">
            <li><a href="registrationAgent.php">Agent</a></li>
            <li><a href="registrationSeller.php">Seller</a></li>
          </ul>
        </li>
        <li class="det active">
          <a class="activel" href="">User Details
            <span>&rsaquo;</span>
          </a>
          <ul class="user-detail">
            <li><a href="agentDetails.php">Agent Details</a></li>
            <li><a class="activel" href="buyerDetails.php">Buyer Details</a></li>
            <li><a href="sellerDetails.php">Seller Details</a></li>
          </ul>
        </li>
        <li><a href="#">Update Info</a></li>
        <li><a href="#">Remove User</a></li>
        <li><a href="publishNotice.php">Notice</a></li>
        <li><a href="#">Feedback</a></li>
        </ul>
    </nav>
    <div class="content">
      <div class="header">
          <a href="../control/alogout.php">Logout</a>
          <span>Rahul Hassan</span>
          <img src="../files/rh_0023.jpg" alt="">
      </div>
    
      <div class="body-content">
      <h2 class="topic">Buyer Details</h2>
      <input type="text" placeholder="Write buyer name..." id="searchBox" onkeyup="showHint(this.value)">
      <div class="searchBox"> <span id="txtHint"></span></div>
		  <table class="center content-table" id="myTable">
        <thead>
          <tr>
            <th>Photo</th>
            <th>Name</th>
            <th>Date Of Birth </th>
            <th>Gender</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Action</th>
          </tr>
        </thead>
			
        <tbody>
          <?php if ($userQuery->num_rows > 0) {
                 while($row = $userQuery->fetch_assoc()){ ?>
          <tr>
            
            <td><img src="<?php echo $row['b_photo'];?>" alt="Photo"></td>
            <td><?php echo $row['b_firstname']." ".$row['b_lastname']; ?></td>
            <td><?php echo $row['b_dob']; ?></td>
            <td><?php echo $row['b_gender']; ?></td>
            <td><?php echo $row['b_phone']; ?></td>
            <td><?php echo $row['b_email']; ?></td>
            
            <td>
              <a class="editbtn" href=""><button>Edit</button></a>
              <a class="dltbtn" href="../control/buyerDel.php?id=<?php echo $row['b_id'];?>" onclick="return confirm('Do you want to delete <?php echo $row['b_firstname']?>?')"><button>Delete</button></a>
            </td>
            
          </tr>
          <?php   
                    }
                }   
            ?>
          
        <tbody>
			
		  </table>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <div><?php include "footer.php"; ?></div>
    </div>
  </body>
</html>