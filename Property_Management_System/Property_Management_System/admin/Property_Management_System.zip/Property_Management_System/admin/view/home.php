<?php 
    $data = file_get_contents('../data/notice.json');
    $mydata = json_decode($data);
    $notice= $mydata[0]->notice;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Grameen Property Ltd.</title>
    <link rel="stylesheet" href="../css/home.css">
    <script src="../js/jquery.min.js"></script>
    <script src="../js/jQuery.js"></script>
</head>
<body>
    <div class="header">
        <br>
        <img src="../files/gpl.png" alt="">
        <h1>Grameen Property Limited</h1>
    </div>
    <marquee><span><?php echo $notice; ?></span></marquee>
     <!--NAVIGATION-->
        <div class="navplate">
            <div class="navigation">
                <ul>
                    <li class="bl"><a href="#">Home</a>
                    </li>
                    <li><a href="#">Project</a>
                    </li>
                    <li><a href="#">Service</a>
                    </li>
                    <li><a href="#">About Us</a>
                    </li>
                    <li class="br"><a href="#">Login</a>
                        <ul> 
                            <li><a class="fastCh" href="alogin.php">Admin</a></li>
                            <li><a href="../../agent/login.php">Agent</a></li>	
                            <li><a href="../../seller/view/seller_login.php">Seller</a></li>	
							<li><a href="">Buyer</a></li>	
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
      <!--END OF NAVIGATION    -->
    <div class="container">
        <div class="content">
            <div class="post1">
                <img src="../files/post1.jpg" alt="Grameen Property Ltd.">
                <h2>TYPES OF REAL ESTATE DEVELOPMENTS IN BANGLADESH</h2>
            
                <p class="date">NOVEMBER 18, 2020</p>
                <p>&nbsp; &nbsp;The private housing sector in Bangladesh started its journey in the 1970s. Over the last two decades, the real estate industry in Bangladesh has grown and demand has increased due to a high urbanization rate. Especially after 1990, an industrial boom sprang in the country. It initiated the need for industrial buildings, corporate offices, housing units, roads and other types of infrastructure. To supply the market’s needs and grab the business opportunity, several real estate development companies entered the industry. Delivering quality and gradually gaining trust, a handful of developers are now dominating the real estate sector across multiple segments. Let’s go through these segments of real estate developments in Bangladesh. <span class="hide">Studies indicate that Dhaka has an increasing urbanization rate of 3.25% per annum. Due to rapid rural to urban migration and high population growth, more people choose Dhaka as their destination for better opportunities. Since the influx is growing, the demand for accomodation is also increasing with the trend. A large portion of this accomodation demand is for residential apartments in Dhaka.</span></p><br>
                <p class="hide">Indicate that Dhaka has an increasing urbanization rate of 3.25% per annum. Due to rapid rural to urban migration and high population growth, more people choose Dhaka as their destination for better opportunities. Since the influx is growing, the demand for accomodation is also increasing with the trend.It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. A large portion of this accomodation demand is for residential apartments in Dhaka.</p>
                <button id="post1btn">Read More</button><br><br>
            </div>
            <table>
                <tr><td>
                <div class="post2">
                    <br>
                    <img src="../files/post2.jpg" alt="Grameen Property Ltd.">
                    <h2>CONVENTIONAL RESIDENTIAL APARTMENTS</h2>
                    <p class="date">JUN 18, 2021</p>
                    <p>&nbsp; &nbsp;Studies indicate that Dhaka has an increasing urbanization rate of 3.25% per annum. Due to rapid rural to urban migration and high population growth, more people choose Dhaka as their destination for better opportunities. A large portion of this accomodation demand is for residential apartments in Dhaka.</p>
                    <p class="hide1">Indicate that Dhaka has an increasing urbanization rate of 3.25% per annum. Due to rapid rural to urban migration and high population growth, more people choose Dhaka as their destination for better opportunities. <span class="hide1">Studies indicate that Dhaka has an increasing urbanization rate of 3.25% per annum. Due to rapid rural to urban migration and high population growth, more people choose Dhaka as their destination for better opportunities. Since the influx is growing, the demand for accomodation is also increasing with the trend. A large portion of this accomodation demand is for residential apartments in Dhaka.</span></p>
                
                    <button id="post2btn">Read More</button><br><br>
                </div> 
                </td><td> 
                <div class="post3">
                    <br>
                    <img src="../files/post3.jpg" alt="Grameen Property Ltd.">
                    <h2>LAND DEVELOPMENTS</h2>
                    <p class="date">JUN 22, 2021</p>
                    <p>&nbsp; &nbsp;While most real estate projects are concentrated in residential and commercial buildings, land is also one of the major real estate developments in Bangladesh. Urban areas are gradually expanding to sustain the need for future accommodation. There is also a growing trend for industrial buildings outside the city area which requires massive land development as well. <span class="hide2">There is also a growing trend for industrial buildings outside the city area which requires massive land development as well. Since the influx is growing, the demand for accomodation is also increasing with the trend. more people choose Dhaka as their destination for better opportunities. Since the influx is growing, the demand for accomodation is also increasing with the trend.</span><p>
                    <button id="post3btn">Read More</button><br><br>
                </div>
                </td> </tr>
            </table>
        </div>
    </div>    
    </div>
    <div><?php include "footer.php"; ?></div> 
</body>
</html>