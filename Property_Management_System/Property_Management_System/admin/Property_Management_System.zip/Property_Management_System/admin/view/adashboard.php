<?php
session_start();
if (empty($_SESSION["username"]))
{
    header("Location: ../control/alogout.php"); // Redirecting To Home Page
}
$cookie_name = "LogInfo";
$cookie_value = "You already logged within 7 days";

setcookie($cookie_name, $cookie_value, time() + (86400 * 7) , "/");
if (!isset($_COOKIE[$cookie_name]))
{
    $cookieInfo = "You are logged in first time.";
}
else
{
    $cookieInfo = $_COOKIE[$cookie_name];
}

?>
<!DOCTYPE html>
<html>

<head>
  <title>Dashboard</title>
  <link rel="stylesheet" href="../css/sidebar.css"> 
  <script>
    alert("<?php echo $cookieInfo ?>");
    // $(document).ready(function(){
    //   $(".dsimg").click(function(){
    //     $(".dsimg").animate({width: '100%'}, 3000);
    //   });
    // });
  </script>
</head>

<body>
  <nav class="sidebar">
    <div class="text">
      <a href="home.php"><img src="../files/gpl.png" alt=""></a> <span>Admin Panel</span> </div>
    <ul>
      <li class="active"><a class="activel" href="adashboard.php">Dashboard</a></li>
      <li class="reg"> <a href="">Registration
        <span>&rsaquo;</span>
        </a>
        <ul class="reg-user">
          <li><a href="registrationAgent.php">Agent</a></li>
          <li><a href="registrationSeller.php">Seller</a></li>
        </ul>
      </li>
      <li class="det"> <a href="">User Details
          <span>&rsaquo;</span>
        </a>
        <ul class="user-detail">
          <li><a href="agentDetails.php">Agent Details</a></li>
          <li><a href="buyerDetails.php">Buyer Details</a></li>
          <li><a href="sellerDetails.php">Seller Details</a></li>
        </ul>
      </li>
      <li><a href="#">Update Info</a></li>
      <li><a href="#">Remove User</a></li>
      <li><a href="publishNotice.php">Notice</a></li>
      <li><a href="#">Feedback</a></li>
    </ul>
  </nav>
  <div class="content">
    <div class="header">
      <h3>Grameen Property Ltd.</h3> 
      <a href="../control/alogout.php">Logout</a> 
      <span>Rahul Hassan</span> 
      <img src="../files/rh_0023.jpg" alt=""> 
    </div> 
      <img class="dsimg" src="../files/dashboard.png" alt="">
    <div>
      <?php include "footer.php"; ?>
    </div>
  </div>
  
</body>

</html>