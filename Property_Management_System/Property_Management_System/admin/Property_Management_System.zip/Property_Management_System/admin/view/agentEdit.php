<?php 
	include '../control/aEditCheck.php';
?>
<html>
	<head>
		<title>Update Agent</title>
		<link href="https://fonts.googleapis.com/css2?family=Teko:wght@400&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="../css/addUpdateAgent.css">
	</head>
	<body>
		<div class="main">	
			<h2 style="text-align:center; color:#525252">Update Agent Information</h2>
            <div class="pimg"><img src="<?php echo $aphoto; ?>" alt="" width="100px"></div><br><br>
			You must have to fill (<span style="color:red">*</span>) fields.<br><br>
			<form action="" name="forms" method="post">
                
				<div>
                    <br>
                    <input type="hidden" name="username" value="<?php echo $username; ?>">
					<label>Name</label>
                    <input class="nwd lname align" type="text" value="<?php echo $lname; ?>" name="lname" placeholder="Last Name">
                    <input class="nwd fname align" id="fname" type="text" value="<?php echo $fname; ?>" name="fname" placeholder="First Name">
					<span style="color:red;"  id="err_fname">*<?php echo $err_fname." ".$err_lname; ?></span>
					<br><br>
				
					<label>Date Of Birth</label>
					<input class="ibox align" type="date" id="dob" value="<?php echo $dob; ?>" name="dob">
					<span style="color:red;" id="err_dob">*<?php echo $err_dob;?></span>
					<br><br>
					
					<label>Gender</label>
					<label class="ibox align">
					<input type='radio' name='gender' value='Female'<?php echo $radio1; ?>>Female
                    <input type='radio' name='gender' value='Male' <?php echo $radio2; ?> >Male
                    <input type='radio' name='gender' value='Other'<?php echo $radio3; ?> >Other
					</label>
					<span style="color:red;" id="err_gender">*<?php echo $err_gender;?></span>
					<br><br>
					
					<label>Phone</label>
					<input class="ibox align" id="phone" type="phone" value="<?php echo $phone; ?>" name="phone">
					<span style="color:red;" id="err_phone">*<?php echo $err_phone;?></span>
					<br><br>
					
					<label>Email</label>
					<input class="ibox align" type="email" id="email" value="<?php echo $email; ?>" name="email">
					<span style="color:red;" id="err_email">*<?php echo $err_email;?></span>
				</div><br><br>
				<div class="all-btn">
				<a class="back" href="agentDetails.php">Back</a>
				<input class="btn" type="submit" name="update" value="Update">
				</div>
			</form>
		</div>
	</body>
</html>