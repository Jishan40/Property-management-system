<?php
    session_start(); 
    include "../control/publishNoticeCheck.php";
    if(empty($_SESSION["username"])) 
    {
        header("Location: ../control/alogout.php"); // Redirecting To Home Page
    }
    
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Publish Notice</title>
        <link rel="stylesheet" href="../css/sidebar.css">
        <link rel="stylesheet" href="../css/notice.css">
    </head>
  <body>
    <nav class="sidebar">
      
      <div class="text"><img src="../files/gpl.png" alt="">
      <span>Admin Panel</span> </div>
      <ul>
        <li><a href="adashboard.php">Dashboard</a></li>
        <li class="reg">
          <a href="">Registration
          <span>&rsaquo;</span>
          </a>
          <ul class="reg-user">
            <li><a href="registrationAgent.php">Agent</a></li>
            <li><a href="registrationSeller.php">Seller</a></li>
          </ul>
        </li>
        <li class="det">
          <a href="">User Details
            <span>&rsaquo;</span>
          </a>
          <ul class="user-detail">
            <li><a href="agentDetails.php">Agent Details</a></li>
            <li><a href="buyerDetails.php">Buyer Details</a></li>
            <li><a href="sellerDetails.php">Seller Details</a></li>
          </ul>
        </li>
        <li><a href="#">Update Info</a></li>
        <li><a href="#">Remove User</a></li>
        <li class="active"><a class="activel" href="publishNotice.php">Notice</a></li>
        <li><a href="#">Feedback</a></li>
      </ul>
    </nav>
    <div class="content">
        <div class="header">
            <a href="../control/alogout.php">Logout</a>
            <span>Rahul Hassan</span>
            <img src="../files/rh_0023.jpg" alt="">
        </div>
        <div class="body-content">
            <form action="" method="post">

                <h4>Write your notice:</h4>
                
                <p style="color:green;"><?php echo $msg; ?></p>
                <p style="color:red;"> <?php echo $err_notice; ?> </p>

                <textarea name="notice" cols="30" rows="10"></textarea><br>
                <input type="submit" name="publish" value="Publish">
            </form>
            
        </div>
        <div><?php include "footer.php"; ?></div>
    </div>
  
  </body>
</html>
