<?php
    include('../control/alogincheck.php');
    if(isset($_SESSION['username'])){
        header("location: adashboard.php");
    }
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Admin Login</title>
    <link rel="stylesheet" href="../css/adminLogin.css">
    <script>
      function myFunction() {
        var x = document.getElementById("pass");
        if (x.type == "password") {
          x.type = "text";
        } else {
          x.type = "password";
        }
      }
    </script>
  </head>
  <body>
    <div class="center">
      <a href="home.php"><img width="165px" src="../files/gpl.png" alt=""></a>
      <form method="post">
        <p><?php echo $error; ?></p>
        <div class="txt_field">
        
          <input name="username" type="text" required>
          <span></span>
          <label>Username</label>
        </div>
        <div class="txt_field">
          <input id="pass" name="password" type="password" required>
          <span></span>
          <label>Password</label>
        </div>
        <div><input class="showpass" type="checkbox" onclick="myFunction()"> Show Password</div>
        <div class="pass"><a href="aForgotpass.php">Forgot Password?</a></div>
        <input class="submitbtn" name="submit" type="submit" value="Login">
      </form>
    </div>
  </body>
</html>
