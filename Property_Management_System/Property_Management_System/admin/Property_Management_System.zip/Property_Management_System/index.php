<?php
    header("location: admin/view/home.php");
?>