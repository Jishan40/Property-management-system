function validateForm() {
    var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    var uname = document.getElementById("uname").value;
    var dob = document.getElementById("dob").value;
    var gender = document.getElementById("gender");
    var phone = document.getElementById("phone").value;
    var email = document.getElementById("email").value;
    var pass = document.getElementById("pass").value;
    var file = document.getElementById("filetoupload").value;
    var patt = /^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/;
    var res = patt.test(email);
    
    if (fname == "") {
     document.getElementById("err-fname").innerHTML="First name need";
      return false;
    }
    if (lname == "") {
        document.getElementById("err-lname").innerHTML="please write a last name";
         return false;
    }
    if (uname == "") {
        document.getElementById("err-uname").innerHTML="please write a username";
         return false;
    }
    if (dob == "") {
        document.getElementById("err-dob").innerHTML="please provide dob";
         return false;
    }
    if (phone == "") {
        document.getElementById("err-phone").innerHTML="please write phone number";
         return false;
    }

    if(email == ""){
        document.getElementById("err-email").innerHTML="Please provide a valid email";
        return false;
    }else if(!res){

      document.getElementById("err-email").innerHTML="Email format is not correct";
      return false; 
    }
    if (pass == "") {
     document.getElementById("err-pass").innerHTML="Please fill out password";
      return false;
    }else if(pass.length < 4){
        document.getElementById("err-pass").innerHTML="Password have to 4 character long";
    }
    
    if (file == "") {
        document.getElementById("err-file").innerHTML="Please upload a file";
        return false;
    }
    
}
