<?php
include('../control/seller_login_check.php');

// if(isset($_SESSION['username'])){
//     header("location: seller_login.php");
// }
?>
<!DOCTYPE html>
<html>
<head>
    <title>seller login page</title>
</head>
<body>
<a href="../../"><img width="165px" src="../files/gpl.png" alt=""></a>

<form action="" method="post">

<h2>Grameen Property Limited</h2>
    <style>
    h2 {
	  color: white;
      background-color: rgb( 0, 204, 0) ;
	  text-align: center;
	}
   </style>
<h3>Seller Login</h3>
    <style>
    h3 {
	  color: lightblue;
      background-color: rgb( 255, 153, 0) ;
	  text-align: center;
	}
   </style>
Username<br>
<input type="text" name="username"><br><br>

Password<br>
<input type="password" name="pass"><br><br><br>
<input type="submit" name="submit">
 <h4>Registration as seller</h4>
   <style>
    h4 {
	  color: green;
      background-color: rgb( 255, 153, 0) ;
	  text-align: center;
	}
   </style>
 
<tr>
<a href="seller_registration.php">REGISTRATION</a>
</tr>
    <style>
    a {
	  color: green;
      background-color: rgb( 0, 0, 0) ;
	  text-align: center;
	}
   </style>
</form>
</body>
</html>