<html>

<head>
	<title> seller information </title>
</head>

<body>
	<p>
		<h1>Seller</h1> </p>
		  <style>
    h1 {
	  color: green ;
      background-color: rgb( 255, 153, 0) ;
	  text-align: center;
	}
   </style>
	<h3 align="right">
			    <hr>
				
		       
		        
		   </h3>
	<h4> <b>
             <ul>
			   <li> <a href=""> Dashboard   </a></li><hr>
                <li> <a href= "editProfile.php"> View Profile </a> </li><hr>
                <li> <a href=""> Edit Profile </a></li><hr>
                <li> <a href="">Change Password</a> </li><hr>
            <li> <a href="">Buyers</a> </li></ul><hr> </ul>
		     <h4/></b> 
		    <h2 > MY PROFILE </h2>
			<style>
                  h2 {
	              color: green ;
                  background-color: rgb( 255, 153, 0) ;
	              text-align: center;
	               }
   </style>
	          Name: ASHRAFUR RAHAMAN<br><br>
			  Email: ashraf.jishan.73@gmail.com <br><br>
		      Contact no:01622916008<br><br>
		      Username: jishan<br><br>

			
	
		  
		
		   
	 </body>
	 
</html>