<?php include "../control/s_registration_check.php"; ?>
<!DOCTYPE html>
<html>
	<head>
		<title>Seller Registration</title>
		<script src="../js/validationReg.js"></script>
	</head>
	<body>
    <a href="seller_login.php"><img width="165px" src="../files/gpl.png" alt=""></a>
		<h3>Seller Registration</h3>
		<style>
        h3 {
	      color: lightgreen;
          background-color: rgb(102, 102, 102) ;
	      text-align: center;
	           }
          </style>
		
		<hr>
	
		<form action="" method="post" onsubmit="return validateForm()" enctype="multipart/form-data">
			<table>
				<tr>
				<td>First Name :</td>
				<td><input name="fname" id="fname" type="text"> <span id="err-fname" >*</span></td>
				</tr>

				<tr>
				<td>Last Name :</td>
				<td><input name="lname" id="lname" type="text"> <span id="err-lname" >*</span></td>
				</tr>

				<tr>
				<td>Username :</td>
				<td><input name="uname" id="uname" type="text"> <span id="err-uname" >*</span></td>
				</tr>

				<tr>
				<td>Date of birth :</td>
				<td><input name="dob" id="dob" type="date"> <span id="err-dob" >*</span></td>
				</tr>

				<tr>
				<td>Gender :</td>
				<td>
					<select name="gender" id="gender">
					<option value="Male">Male</option>
					<option value="Female">Female</option>
					<option value="Other">Other</option>
					</select>
					<span id="err-gender" >*</span></td>
				</tr>

				<tr>
				<td>Phone :</td>
				<td><input name="phone" id="phone" type="text"> <span id="err-phone" >*</span></td>
				</tr>

				<tr>
				<td>Email :</td>
				<td><input type="text" id="email" name="email"> <span id="err-email" >*</span></td>
				</tr>
				
				<tr>
				<td>Password :</td>
				<td><input type="password" id="pass" name="pass"> <span id="err-pass" >*</span></td>
				</tr>
			   
				<tr>
					<td>Photo :</td>
					<td>
						<input type="file" id="filetoupload" name="filetoupload">
						<span id="err-file" >*</span>
					</td>
				</tr>
				
				<tr>
					<td><br><input type="submit" value="Submit">&nbsp;&nbsp;<input type="reset" value="Reset"></td>
				</tr>
			</table>
		</form>

	</body>
</html>