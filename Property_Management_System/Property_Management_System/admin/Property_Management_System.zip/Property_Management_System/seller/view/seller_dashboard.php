<?php
session_start(); 
if(empty($_SESSION["username"])) 
{
header("Location: ../control/s_logout.php"); // Redirecting To Home Page
}

?>


<!DOCTYPE html>
<html lang="en">
<head>

    <title>seller dashboard</title>
</head>
<body>
<br><center><a href="home.php"><img width="165px" src="../files/gpl.png" alt=""></a></center>
<button><a href="../control/s_logout.php">Logout</a></button><br><br>

<center></center>
<table width="100%" >
<tr>
<th style="border: 2px solid green"> <a href="viewprofile.php"> Profile</a></th>
  <style>
    a {
	  color: green;
      background-color: rgb(0, 0, 0) ;
	  
	}
   </style>
<th style="border: 2px solid blue"><b href="">Add Property</b></th>
    <style>
    b {
	  color: yellow;	
	  background-color: rgb(0, 0, 0) ;
	  cursor: pointer;
	}
   </style>
<th style="border: 2px solid green"><c href="">Customize Property</c></th>
    <style>
    c {
	  color: green;
      background-color: rgb(0, 0, 0) ;
      cursor: pointer;	  
	}
   </style>
<th style="border: 2px solid blue"><d href="">Transaction</d></th>
    <style>
    d {
	  color: blue;
      background-color: rgb(0, 0, 0) ;	
      cursor: pointer;	  
	}
   </style>
</tr>
<tr>
<th colspan="4">
    <img src="../files/s_dashboard.jpg" alt="" width="100%">
</th>
</tr>
</table>
</center>
</body>
</html>