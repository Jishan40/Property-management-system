<?php

session_start(); 

 $error="";
// store session data
$uname="admin";
$pword="1234";

if (isset($_POST['username'])) {
	if ($_POST['username']==$uname && $_POST['pass']==$pword) {
		$_SESSION['username'] = $uname;
		header("location: ../view/seller_dashboard.php");
	}
	else{
		$msg="username or password invalid";
	}

}



?>
