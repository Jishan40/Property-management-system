<?php
    include "../model/db.php";

    $fname= $lname= $username= $dob= $gender= $phone= $email= $pass="";
    $validatename = "";
    $validateemail = $validatepass = $validatecmt= "";
    $validatecheckbox = "";
    $validateradio = "";
    $infoh = $fileInfo =$infog = $target_file=  "";
    $name = $email = $gender = "";
    if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        $fname = $_REQUEST["fname"];
        $lname = $_REQUEST["lname"];
        $username = $_REQUEST["uname"];
        $dob = $_REQUEST["dob"];
        $gender = $_REQUEST["gender"];
        $phone = $_REQUEST["phone"];

        $email = $_REQUEST["email"];
        $pass = $_REQUEST["pass"];
        

        if (empty($_REQUEST["fname"]) || (strlen($_REQUEST["fname"]) < 3))
        {
            $validatename = "You must enter name";

        }
        else
        {
            $validatename = "Your name is " . $name;
        }

        if (empty($email) || !preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $email))
        {
            $validateemail = "You must enter email";
        }
        else
        {
            $validateemail = "Your email is " . $email;
        }

        if(isset($_POST['password'])) {
            $password = $_POST['password'];
        
            if(strlen($password) < 4 ) {
                $validatepass = "Password must be 4 characters";
            } else {
                $validatepass = "Your password is entered";
            }
        }

        $target_file = "../files/".$_FILES["filetoupload"]["name"];

        if(move_uploaded_file($_FILES["filetoupload"]["tmp_name"], $target_file)){
           // echo "You have uploaded ".$_FILES["filetoupload"]["name"];
        } else{
            $fileInfo = "Sorry, there was an error uploading your file.";
        }
    
        $connection = new db();
        $conobj=$connection->OpenCon();
        $userQuery=$connection->addSeller($conobj,"seller", $fname, $lname, $username, $dob, $gender, $phone, $email, $pass, $target_file);
        $connection->CloseCon($conobj);
        $msg = "Data Inserted Successfully";
       
    }

?>
