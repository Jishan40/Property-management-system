<?php
class db{
    
    function OpenCon()
    {
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $db = "pms";
    $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
    
    return $conn;
    }
    
    function addSeller($conn, $table, $aFirstname, $aLastname, $aUsername, $aDob, $aGender, $aPhone, $aEmail, $aPassword, $aPhoto)
    {
        $result = $conn->query("INSERT INTO $table VALUES('','$aFirstname','$aLastname','$aUsername','$aDob','$aGender', '$aPhone', '$aEmail', '$aPassword', '$aPhoto')");
        return $result;
    }
   

    function CloseCon($conn)
    {
        $conn -> close();
    }
    
}

?>